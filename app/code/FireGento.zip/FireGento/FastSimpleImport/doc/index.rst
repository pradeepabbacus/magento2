.. FireGento_FastSimpleImport2 documentation master file, created by
   sphinx-quickstart on Tue Oct  4 22:27:49 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to FireGento_FastSimpleImport2's documentation!
=======================================================

Contents:

.. toctree::
   :caption: User Documentation
   :maxdepth: 2

   Installation
   Products
   Category
   Fieldnames




Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

