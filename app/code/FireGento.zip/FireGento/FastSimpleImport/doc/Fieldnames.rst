Appendix : Fieldnames 
==========================

Products Fields
---------------------------------------------
.. csv-table:: "Product Fields"
   :header: "Fieldname","Explanation"
   :widths: 15,30
   :file: fields.csv
