<?php
/**
 * Import proxy category resource
 *
 * @author Bogdan Lewinsky <b.lewinsky@youwe.nl>
 */
namespace FireGento\FastSimpleImport\Model\Import\Proxy\Category;

class ResourceModel extends \Magento\Catalog\Model\ResourceModel\Category
{
}
