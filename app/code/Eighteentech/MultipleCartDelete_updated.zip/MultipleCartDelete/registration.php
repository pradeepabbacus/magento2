<?php
/**
 * Module registration file
 *
 * Copyright (c) 2021. 18th DigiTech Team. All rights reserved.
 * @author  18th Digitech <info@18thdigitech.com>
 * @package Eighteentech_WhatsAppChat
 */
use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::MODULE, 'Eighteentech_MultipleCartDelete', __DIR__);
