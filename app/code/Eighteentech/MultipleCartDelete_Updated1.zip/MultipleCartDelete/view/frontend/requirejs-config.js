var config = {
    "map": {
        "*": {
            "MultipleCartDelete": "Eighteentech_MultipleCartDelete/js/MultipleCartDelete" 
        } 
    }
};